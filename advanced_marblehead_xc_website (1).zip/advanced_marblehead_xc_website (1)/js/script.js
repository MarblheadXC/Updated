// Preloader functionality
window.addEventListener('load', () => {
  const preloader = document.getElementById('preloader');
  preloader.style.display = 'none';
});

// Dark mode toggle
const themeButton = document.getElementById('theme-btn');
const body = document.body;

themeButton.addEventListener('click', () => {
  body.classList.toggle('dark-mode');
  if (body.classList.contains('dark-mode')) {
    themeButton.textContent = 'Switch to Light Mode';
  } else {
    themeButton.textContent = 'Switch to Dark Mode';
  }
});

// Mobile menu toggle
const navToggle = document.querySelector('.nav-toggle');
const navLinks = document.querySelector('.nav-links');

navToggle.addEventListener('click', () => {
  navLinks.classList.toggle('show');
});

// Smooth scroll to anchor links
const links = document.querySelectorAll('a[href^="#"]');

for (const link of links) {
  link.addEventListener('click', (e) => {
    e.preventDefault();

    const targetId = link.getAttribute('href');
    const targetElement = document.querySelector(targetId);

    window.scrollTo({
      top: targetElement.offsetTop,
      behavior: 'smooth',
    });
  });
}

// Modal functionality
const modal = document.getElementById("myModal");
const openModalButton = document.getElementById("openModal");
const closeButton = document.querySelector(".close");

openModalButton.addEventListener("click", () => {
  modal.style.display = "block";
});

closeButton.addEventListener("click", () => {
  modal.style.display = "none";
});

window.addEventListener("click", (e) => {
  if (e.target == modal) {
    modal.style.display = "none";
  }
});

// Scroll-triggered animations
const elementsToAnimate = document.querySelectorAll('.animate-on-scroll');

const animateOnScroll = () => {
  const windowHeight = window.innerHeight;
  elementsToAnimate.forEach((el) => {
    const elementTop = el.getBoundingClientRect().top;
    if (elementTop < windowHeight - 100) {
      el.classList.add('in-view');
    } else {
      el.classList.remove('in-view');
    }
  });
};

window.addEventListener('scroll', animateOnScroll);

// Form validation
const form = document.getElementById('contactForm');
const formError = document.getElementById('formError');

form.addEventListener('submit', (e) => {
  const name = form.querySelector('input[name="name"]');
  const email = form.querySelector('input[name="email"]');
  const message = form.querySelector('textarea[name="message"]');

  if (!name.value || !email.value || !message.value) {
    e.preventDefault();
    formError.style.display = 'block';
    formError.textContent = 'Please fill in all fields!';
  } else if (!validateEmail(email.value)) {
    e.preventDefault();
    formError.style.display = 'block';
    formError.textContent = 'Please enter a valid email address.';
  }
});

function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email);
}
